(function ($) {
    'use strict';
    $(function () {
        $('[data-toggle="offcanvas"]').on("click", function () {
            $('.sidebar-offcanvas').toggleClass('active')
        });
    });

    $(".card-body").html('Home');

    $.getJSON( "assets/js/list.json", function( data ) {
        var ele = document.getElementById('items');
        for (var i = 0; i < data.items.length; i++) {
            ele.innerHTML = ele.innerHTML +
               '<li class="nav-item  '+data.items[i]['grade']+'">'+
                        '<a class="nav-link clearfix leftnav" data-toggle="collapse">'+
                        '<span class="col-6"><span class="menu-title">'+data.items[i]['name'] +'</span>'+
                        '<span class="smaller text-muted">'+data.items[i]['sufix'] +'</span></span>'+
                        '<span class="col-3"><span class="menu-title">'+data.items[i]['percent'] +'</span>'+
                        '<i class="fa fa-chevron-'+data.items[i]['grade']+' icon-sm"></i></span>'+
                        '<span class="text-muted col-3">'+data.items[i]['value'] +'</span>'+
                        '</a>';
                '</li>'
        }
    }).done(function() {
        $('#sidebar').find(".leftnav").click(function () {
            $(".card-body").html('');
            $('.page-header h4').html($(this).html())
            $(".card-body").html($(this).html());
        })
    });



    $(".link").click(function () {
        $(".card-body").html('');
        $('.page-header h4').html($(this).html())
        $(".card-body").html($(this).html());
    });

    $("#home").click(function () {
        $('.page-header h4').html('Rest full API Home  content');
        $.ajax('https://jsonplaceholder.typicode.com/posts')
            .done(function(posts){
                $(".card-body").html('');
                var content = document.getElementById('contentBody');
                for(var i=0; i < 10; i++){
                    content.innerHTML = content.innerHTML+
                        '<div class="d-flex justify-content-between">' +
                        '  <h4 class="mb-0">'+posts[i]['title']+'</h4>' +
                        '</div>' +
                        '<p>'+posts[i]['body']+'</p>'

                }
            });
    });

    $("#home").trigger("click");


    $("#tableLink").click(function(){

        $('.page-header h4').html('Restfull API Table Data');
        var jqxhr = $.ajax( "https://reqres.in/api/users?page=2" )
        .done(function(result) {
            $(".card-body").html('')
            var table = '<div class="table-responsive">\n' +
                        '<table class="table table-striped table-hover">\n' +
                        '  <thead>\n' +
                        '    <tr>\n' +
                        '      <th>ID</th>\n' +
                        '      <th>Customer</th>\n' +
                        '      <th>First name</th>\n' +
                        '      <th>Last name</th>\n' +
                        '      <th>Avatar</th>\n' +
                        '    </tr>\n' +
                        '  </thead>\n' +
                        '  <tbody id="tdata">\n' +
                        '  </tbody>\n' +
                        '</table>\n' +
                        '</div>';

            $(".card-body").append(table);
            var tbody = document.getElementById('tdata');
            for (var i = 0; i < result.data.length; i++) {
                tbody.innerHTML = tbody.innerHTML+
                    '<tr>' +
                    '<td>'+result.data[i]['id']+'</td>' +
                    '<td>'+result.data[i]['email']+'</td>' +
                    '<td>'+result.data[i]['first_name']+'</td>' +
                    '<td>'+result.data[i]['last_name']+'</td>' +
                    '<td> <img src="'+result.data[i]['avatar']+'" width="50" height="50" /></td>' +
                    '</tr>'
            }

        })
        .fail(function() {
            //alert( "error" );
        })
        .always(function() {
            //alert( "complete" );
        });
    });
})(jQuery);